java -classpath "../bin:../lib/db4o.jar" bbdd2.p2.pruebas.PruebaQBE
